<?php
	$host = "localhost";
	$user = "root";
	$password = "";
	$db = "book_mgmt";
	$conn = mysqli_connect($host,$user,$password,$db);
	if(!$conn){
		die("Connection Error");
	}
#print_r("connection success");
?>