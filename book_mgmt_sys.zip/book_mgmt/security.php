<?php
//@ob_start();
session_start();
//print_r($_SESSION);
include ('connection.php');
if($conn)
{
    // echo "Database Connected";
}
else
{
    header("Location: connection.php");
}
if(!$_SESSION['username'])
{
	header('Location: login.php');
}
if(isset($_SESSION['start_time']) && (time() - $_SESSION['start_time'] > 1800)){
    session_unset();   
    session_destroy(); 
	//header('location:login.php');
}

?>