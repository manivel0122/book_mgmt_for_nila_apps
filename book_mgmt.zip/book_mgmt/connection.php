
<?php
	$host = "localhost";
	$user = "root";
	$password = "";
	$db = "shop_management";
	$conn = mysqli_connect($host,$user,$password,$db);
	if(!$conn){
		die("Connection Error");
	}
#print_r("connection success");
?>