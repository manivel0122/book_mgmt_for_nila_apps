<?php
include "connection.php";
if(isset($_POST['book_id'])){
	$query = "select * from book_details where id = '".$_POST["book_id"]."'";
	$get_bookdetails = mysqli_query($conn,$query);
	$book_details = mysqli_fetch_array($get_bookdetails);
	echo json_encode ($book_details);
	
}
if(isset($_POST['req_id'])){
	$query = "select * from book_details where id = '".$_POST["req_id"]."'";
	$get_bookdetails = mysqli_query($conn,$query);
	$book_details = mysqli_fetch_array($get_bookdetails);
	echo json_encode ($book_details);
}
?>