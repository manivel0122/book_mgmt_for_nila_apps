<?php
if(!isset($_SESSION)){
session_start();
}
include ('connection.php');
if($conn)
{
    // echo "Database Connected";
}
else
{
    header("Location: connection.php");
}
if(!$_SESSION['username'])
{
	header('Location: login.php');
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 60)) {
    // last request was more than 30 minutes ago
    session_unset();     // unset $_SESSION variable for the run-time 
    session_destroy();   // destroy session data in storage
} else{
$_SESSION['LAST_ACTIVITY'] = time(); // update last 
}
/*if(isset($_SESSION['start_time']) && (time() - $_SESSION['start_time'] > 30)){
if(isset($_SESSION['last_activity']) && ( time()-$_SESSION['last_activity'] > 60)){
    session_unset();   
    session_destroy(); 
	
}else {
	$_SESSION['last_activity'] = time();
}*/

?>