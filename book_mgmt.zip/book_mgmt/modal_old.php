<?php
include('security.php');
include "connection.php";
include('includes/header.php'); 
include('includes/navbar.php'); 
 #######   ADD / EDIT Form POST METHOD #######
 
if(!empty($_POST)){
	$book_no = $_POST['book_no'];
	$book_name = $_POST['book_name'];
	$book_author = $_POST['author_name'];
	$book_count = $_POST['book_copies'];
	$book_availability = $_POST['book_status'];
	$output = "";
	$msg = "";
	if ($_POST['book_id']!=''){	
		$query = "update book_details set book_no = '$book_no' , book_name = '$book_name', book_author = '$book_author', books_count = '$book_count' , books_availability = '$book_availability' where id = '".$_POST["book_id"]."'" ;
		$msg = "Your Data Updated";
	}else {
		$query = "insert into book_details(book_no,book_name,book_author,books_count,books_availability) values ('$book_no','$book_name','$book_author','$book_count','$book_availability')";
		$msg = "Your Data Inserted";
	}
	$result = mysqli_query($conn,$query);	
	$count = mysqli_affected_rows($conn);
	if($count == 1){
		echo '<script> alert("Data Saved"); </script>';
	}else{
		echo '<script> alert("Data Not Saved"); </script>';
	}	
}
?>

<html>
<head>
</head>

<meta charset = "UTF-8">
<meta name = "viewport" content = "width=device-width, initial-scale=1.0">
<meta http-equiv = "X-UA-Compatible" content = "ie=edge">
<title> Books Management System </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<body>
<!-- Modal Start !-->
<!-- Button trigger modal -->
<!-- Modal -->

<div class="modal fade" id="addbookmodal" tabindex="-1" aria-labelledby="addbookmodal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addbookmodal">ADD / Edit Books</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
	<form action="" method="post">
		<div class="modal-body">
        <!--  Body Book!-->
				<input type="hidden" class="form-control" id= "book_id" name="book_id" >
			<div class="form-group">
				<label >Book Number</label>
				<input type="text" class="form-control" id= "book_no" name="book_no" aria-describedby="book_no" placeholder="" required>
			</div>
			<div class="form-group">
				<label >Book Name</label>
				<input type="text" class="form-control" id= "book_name" name="book_name" aria-describedby="book_name" placeholder="" required>
			</div>
			<div class="form-group">
				<label >Book Author Name</label>
				<input type="text" class="form-control" id= "author_name" name="author_name" aria-describedby="author_name" placeholder="" required>
			</div>
			<div class="form-group">
				<label >Year of Publishing</label>
				<input type="text" class="form-control" id= "book_copies" name="book_copies" aria-describedby="book_copies" placeholder="" required>
			</div>
			<div class="form-group">
					<label >STATUS</label>

			<div class="input-group mb-3">
			<select class="form-select" id="request_status" name="request_status" >
			<option selected>Choose...</option>
			<option value="1">Active</option>
			<option value="2">Inactive</option>
			</select>
  
</div>
</div>
			
		<!-- End Body!-->
     
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" name= "addbookslist" id= "addbookslist1"  value = "Save" class="btn btn-primary">
      </div>
	  </form>
    </div>
  </div>
</div>


<!-- Modal End !-->
	<div class = "container"> 
		<div class = "jumbotron">
			<div class = "card">
				<h2> Books List<h2>
			</div>
			<div class = "card">
				<div class = "card-body">
					<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addbookmodal" style="float: right;" >
						ADD BOOKS
					</button>			
				</div>
			</div>
		</div>
	<!-- Modal Button End !-->	
		<div class = "card">
			<div class = "card-body">
				<table class="table">
				<thead>
					<tr>
					  <th>#</th>
					  <th>Book_NO</th>
					  <th>Book_Name</th>
					  <th>Author_Name</th>
					  <th>Year </th>
					  <th>Status</th>
					  <th>Action</th>
					  
					</tr>
				 </thead>
				 <tbody>
					<?php
					$get_usersdetails = mysqli_query($conn,"select * from book_details") or die(mysql_error());
					$count = 0;
					while($users_details = mysqli_fetch_array($get_usersdetails)) {
						//$id = $count++;
						$usersid = $users_details['id'];
						$book_no = $users_details['book_no'];
						$book_name = $users_details['book_name'];
						$book_author = $users_details['book_author'];
						$books_count = $users_details['books_count'];
						$book_status = $users_details['books_availability'];
								if($book_status == 1) {
									$book_status = "ACTIVE";
								}else {
									$book_status = "INACTIVE";
								}
					?>
				<tr>
                	<td><?php echo $usersid; ?></td>
                    <td><?php echo $book_no; ?></td>
					<td><?php echo $book_name; ?></td>
                    <td><?php echo $book_author; ?></td>
					<td><?php echo $books_count; ?></td>
					<td><?php echo $book_status; ?></td>
                    <td>
						<input type= "button" name ="edit" value="Edit" id = "<?php echo $usersid; ?>" class = "btn btn-primary editbooks" >
                        <a href="books.php?action=edit&nwsevnt_id=<?php echo $usersid; ?>" class="btn btn-sm btn-danger deletebooks">Delete</a>
                    </td>
                </tr>
					<?php } ?>
				 </tbody>
					<?php #echo "No Record Found"; ?>
				</table>
			</div>
		</div>
			<!-- List Page End !-->
	</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<script>
	$(document).ready(function(){
		console.log("Mani");
		$('.editbooks').on('click',function() {
			var book_id = $(this).attr("id");
			console.log(book_id);
			$.ajax({
				url:"fetch_book_details.php",
				method: "post",
				data: {book_id : book_id},
				dataType: "json",
				success: function(data){
					$('#book_no').val(data.book_no);
					$('#book_name').val(data.book_name);
					$('#author_name').val(data.book_author);
					$('#book_copies').val(data.books_count);
					$('#book_status').val(data.books_availability);
					$('#book_id').val(data.id);
					$('#addbookslist').val("update");
					$('#addbookmodal').modal('show');
				}
			});
	});	
});
</script>
</body>
</html>
