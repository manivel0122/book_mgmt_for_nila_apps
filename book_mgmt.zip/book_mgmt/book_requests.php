<?php
include('security.php');
include "connection.php";
include('includes/header.php'); 
include('includes/navbar.php');
//print_r($_SESSION);
 #######   ADD / EDIT Form POST METHOD #######
if($_SESSION['usertype'] == 'USR'){
if(isset($_GET['action']) && ($_GET['action']=='request')){
	$req_id = $_GET['nwsevnt_id'];
	$query = "select * from book_details where id = '".$req_id."'";
	$result = mysqli_query($conn, $query);
	$res = mysqli_fetch_array($result);
	$book_no = $res['book_no'];
	$book_count = $res['books_count'];
	$username =  $_SESSION['name'];	
	$output = "";
	$msg = "";
	if ($req_id!=''){	
		$query_request = "insert into book_request(book_no,username,request_status) values ('$book_no','$username','0')";
		#print_r($query_request);
		$result_new = mysqli_query($conn,$query_request);	
		$query = "insert into notifications(book_no,sender,notification_status) values ('$book_no','$username','0')";
		$msg = "Your Request to be done";
	}else {
			$msg = "Your Request not to be done";
	}
	$result_new = mysqli_query($conn,$query);	
	$count = mysqli_affected_rows($conn);
	if($count == 1){
		echo '<script> alert("Your Request SENT to be Admin	"); </script>';
	}else{
		echo '<script> alert("Your Request not completed); </script>';
	}	
}
?>

<html>
<head>
</head>

<meta charset = "UTF-8">
<meta name = "viewport" content = "width=device-width, initial-scale=1.0">
<meta http-equiv = "X-UA-Compatible" content = "ie=edge">
<title> Books Management System </title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<body>
<!-- Modal Start !-->
<!-- Button trigger modal -->
<!-- Modal -->


<!-- Modal End !-->
	<div class = "container"> 
		<div class = "jumbotron">
			<div class = "card">
				<h2> Requested Book<h2>
			</div>
			<div class = "card">
				</div>
			</div>
		</div>
	<!-- Modal Button End !-->	
		<div class = "card">
			<div class = "card-body">
			<form method="post">
				<table class="table">
				<thead>
					<tr>
					  <th>#</th>
					  <th>Book_NO</th>
					  <th>Book_Name</th>
					  <th>Author_Name</th>
					  <th>Year</th>
					  <th>Action</th>
					  
					</tr>
				 </thead>
				 <tbody>
					<?php
					$get_usersdetails = mysqli_query($conn,"select * from book_details") or die(mysql_error());
					$count = 0;
					while($users_details = mysqli_fetch_array($get_usersdetails)) {
						//$id = $count++;
						$usersid = $users_details['id'];
						$book_no = $users_details['book_no'];
						$book_name = $users_details['book_name'];
						$book_author = $users_details['book_author'];
						$books_count = $users_details['books_count'];
						
					?>
				<tr>
                	<td><?php echo $usersid; ?></td>
                    <td><?php echo $book_no; ?></td>
					<td><?php echo $book_name; ?></td>
                    <td><?php echo $book_author; ?></td>
					<td><?php echo $books_count; ?></td>
				
                    <td>
					
					 <a href="book_requests.php?action=request&nwsevnt_id=<?php echo $usersid; ?>" class="btn btn-sm btn-danger deletebooks">Request-to-Read</a>
					
					
                    </td>
                </tr>
					<?php } ?>
				 </tbody>
					<?php #echo "No Record Found"; ?>
				</table>
			
				</div>
				</form>
		</div>
			<!-- List Page End !-->
	</div>
<?php }?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<script>
	$(document).ready(function(){
		console.log("Mani");
		$('.editbooks').on('click',function() {
			var req_id = $(this).attr('#req_id');
			console.log(req_id);
			$.ajax({
				url:"fetch_book_details.php",
				method: "post",
				data: {req_id : req_id},
				dataType: "json",
				success: function(data){
					
									},
				data: JSON.stringify(req_id)
			});
	});	
});
</script>
</body>
</html>
	